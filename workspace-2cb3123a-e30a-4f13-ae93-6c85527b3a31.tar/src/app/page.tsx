'use client'

import { useState } from 'react'
import { Search, Loader2, ExternalLink, Clock, TrendingUp } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'

interface SearchResult {
  url: string
  name: string
  snippet: string
  host_name: string
  rank: number
  date: string
  favicon: string
}

export default function Home() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [hasSearched, setHasSearched] = useState(false)

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!query.trim()) return

    setIsLoading(true)
    setHasSearched(true)

    try {
      const response = await fetch('/api/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query }),
      })

      if (response.ok) {
        const data = await response.json()
        setResults(data.results || [])
      }
    } catch (error) {
      console.error('Search failed:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-black text-cyan-400 overflow-hidden relative">
      {/* Animated background grid */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-cyan-900/20">
        <div className="absolute inset-0" style={{
          backgroundImage: `linear-gradient(cyan 1px, transparent 1px), linear-gradient(90deg, cyan 1px, transparent 1px)`,
          backgroundSize: '50px 50px',
          opacity: 0.03
        }}></div>
      </div>

      {/* Glitch effect overlay */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/5 to-transparent animate-pulse"></div>
      </div>

      <div className="relative z-10">
        {/* Header */}
        <header className="border-b border-cyan-500/30 backdrop-blur-sm bg-black/50">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="relative w-10 h-10">
                  <img
                    src="/logo.png"
                    alt="CYBERSEARCH Logo"
                    className="w-full h-full object-contain rounded-lg neon-border"
                  />
                </div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent glitch-text">
                  CYBERSEARCH
                </h1>
              </div>
              <div className="flex items-center space-x-4 text-sm text-cyan-600">
                <span className="hidden sm:inline">[NEURAL_NET_ACTIVE]</span>
                <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              </div>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="container mx-auto px-4 py-12">
          {/* Search section */}
          <div className="max-w-4xl mx-auto mb-12">
            <div className="text-center mb-8">
              <h2 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent glitch-text">
                ACCESS THE NET
              </h2>
              <p className="text-cyan-600 text-lg font-mono text-neon">
                &gt; Query the digital consciousness...
              </p>
            </div>

            <form onSubmit={handleSearch} className="relative scanline-effect">
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-lg blur opacity-50 group-hover:opacity-75 transition-opacity neon-border"></div>
                <div className="relative flex items-center">
                  <Input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Enter search query..."
                    className="w-full px-6 py-4 bg-black/80 border-2 border-cyan-500/50 rounded-lg text-cyan-400 placeholder-cyan-700 focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/20 text-lg font-mono"
                  />
                  <Button
                    type="submit"
                    disabled={isLoading || !query.trim()}
                    className="absolute right-2 px-6 py-2 bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-black font-bold rounded-md transition-all duration-200 disabled:opacity-50 neon-border"
                  >
                    {isLoading ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <Search className="w-5 h-5" />
                    )}
                  </Button>
                </div>
              </div>
            </form>

            {/* Quick search suggestions */}
            <div className="mt-6 flex flex-wrap gap-2 justify-center">
              {['AI trends', 'Cybersecurity', 'Web3', 'Tech news', 'Coding'].map((suggestion) => (
                <button
                  key={suggestion}
                  onClick={() => setQuery(suggestion)}
                  className="px-4 py-2 bg-cyan-500/10 border border-cyan-500/30 rounded-full text-cyan-400 hover:bg-cyan-500/20 hover:border-cyan-400/50 transition-all duration-200 text-sm font-mono neon-border hover:text-neon"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>

          {/* Search results */}
          {hasSearched && (
            <div className="max-w-4xl mx-auto">
              {isLoading ? (
                <div className="text-center py-12">
                  <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-cyan-400 text-neon" />
                  <p className="text-cyan-600 font-mono">Scanning the matrix...</p>
                </div>
              ) : results.length > 0 ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-xl font-bold text-cyan-400 text-neon">
                      Search Results [{results.length}]
                    </h3>
                    <div className="flex items-center space-x-2 text-cyan-600 text-sm">
                      <Clock className="w-4 h-4" />
                      <span>{new Date().toLocaleTimeString()}</span>
                    </div>
                  </div>

                  {results.map((result, index) => (
                    <Card
                      key={result.url}
                      className="bg-black/60 border border-cyan-500/30 hover:border-cyan-400/50 transition-all duration-200 hover:shadow-lg hover:shadow-cyan-500/20 neon-border"
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <span className="text-cyan-600 font-mono text-sm">
                                [{String(index + 1).padStart(3, '0')}]
                              </span>
                              <span className="text-purple-400 text-sm font-mono">
                                {result.host_name}
                              </span>
                              {result.date && (
                                <span className="text-cyan-600 text-xs font-mono">
                                  {result.date}
                                </span>
                              )}
                            </div>
                            <h4 className="text-lg font-semibold text-cyan-300 mb-2 hover:text-cyan-200 transition-colors">
                              <a
                                href={result.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center space-x-2 hover:text-neon"
                              >
                                <span>{result.name}</span>
                                <ExternalLink className="w-4 h-4" />
                              </a>
                            </h4>
                            <p className="text-cyan-600 font-mono text-sm leading-relaxed">
                              {result.snippet}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">🔍</div>
                  <p className="text-cyan-600 font-mono text-lg">
                    No results found. Try different keywords.
                  </p>
                </div>
              )}
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className="border-t border-cyan-500/30 mt-20">
          <div className="container mx-auto px-4 py-6">
            <div className="flex flex-col md:flex-row items-center justify-between text-cyan-600 text-sm font-mono">
              <div className="flex items-center space-x-2 mb-2 md:mb-0">
                <TrendingUp className="w-4 h-4" />
                <span>CYBERSEARCH v1.0</span>
              </div>
              <div className="flex items-center space-x-4">
                <span>System Online</span>
                <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}